// // JavaScript Document

// Label Animation
let input = document.querySelectorAll('.tex-field')
input.forEach(function (inp) {
   inp.addEventListener('focus', function () {
      Remove()
      this.nextElementSibling.classList.add('top')
   })
})
function Remove() {
   document.querySelectorAll('.custom').forEach(function (lab) {
      lab.classList.remove('top')
      if (lab.previousElementSibling.value) {
         lab.classList.add('top')
      }
   })
}

// Submit Values
$(document).ready(function(){
   //submit form
   $('#submit').on('click', function(e){
      e.preventDefault();
      var adrs1 = $('#Address1').val();
      var adrs2 = $('#Address2').val();
      var postcode = $('#postcode').val();
      var state = $('#state').val();
   
      var creditCard = $('#cn').val();
      var prodName =$('.prod-name').text();
   
      if(adrs1 !== '' && adrs2 !== '' && postcode !== '' && state !== '' && creditCard !== '' && prodName !== '' ){
         console.log('Product: ' + prodName);
         console.log('Address1: ' + adrs1 + ', ' + 'Address2: ' + adrs2 + ', ' + 'PostCode: ' + postcode + ', ' + 'State: ' + state);
         console.log('Credit Card: ' + creditCard);
         localStorage.setItem("form-succs", 'true');
      }
   })
   
   //only number validation
   $('#phone, #cn, #postcode').on('keypress', function(evt){
      evt = (evt) ? evt : window.event;
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
          return false;
      }
      return true;
   });
   
   //Credt Card Validation
   $('#cn').keyup(function (e) {
      var spaceCondition = $(this).val().split(" ").join("");
      if (spaceCondition.length > 0) {
         spaceCondition = spaceCondition.match(new RegExp('.{1,4}', 'g')).join(" ");
         $(this).val(spaceCondition);
      }
   })

   //Phone number validation 0 & 4
   $('#phone').keyup(function (e) {
      var phNum = $(this).val();
      if(phNum.length >1){
      var phCheck = /^(0)(4)/;
         if (!phCheck.test(phNum)) {
            $(this).css('border', '1px solid red');
         } else {
            $(this).css('border', '1px solid #ccc');
         }
      }else {
         $(this).css('border', '1px solid #ccc');
      }
   });

   //Hide form on success by local storage
   var formSuccs = localStorage.getItem("form-succs");
   if(formSuccs == 'true'){
      $('.form').hide();
      $('.form-sucss-msg').show();
   }

   //Postcode
   $('#postcode').keyup(function (e) {
      var postVal = $(this).val();
      if(postVal.length == 5){
         var url = 'https://www.wsjwine.com/api/address/zipcode/'+postVal;
         $.ajax({
            dataType: "json",
            url: url,
            type:"GET",
            success:function(data)
               {
                  // console.log(data.response);
                  var dataRes = data.response;
                  $('#state').val(dataRes.stateName);
                  $("#city").html("<option value='dataRes.city'>" + dataRes.city + "</option>");
                  if(dataRes.zipCode == '12345'){
                     $('.notice').hide();
                     $('.error-msg').hide();
                  }
                  else{
                     $('.notice').show();
                     $('.error-msg').hide();
                  }
               },
               error: function (jqXHR, exception) { 
                  $('.notice').hide();
                  $('.error-msg').show();
                  $('.error-msg').html('Please check the pincode!');
               },
          });
      }
   });
})